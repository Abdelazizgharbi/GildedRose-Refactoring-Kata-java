package com.gildedrose;

/**
 * This Class is created in order to make in common used names for items
 * @author GHARBI ABDELAZIZ
 *
 */
public class Utils {

	public static final String agedBrie = "Aged Brie";
	public static final String backStage = "Backstage passes to a TAFKAL80ETC concert";
	public static final String sulfuras = "Sulfuras, Hand of Ragnaros";
	public static final String conjured = "Conjured Mana Cake";
	public static final String dexteriry = "+5 Dexterity Vest";
	public static final String elexir = "Elixir of the Mongoose";
	
}
